function bspDGL_Loesen

clear; clc; close all % Aufr�umen
 
dt = 0.01; time = 0:dt:10; % Abtastzeit definieren
[T,X] = ode45(@bspDGL2,time,[0 1]);  % DGL l�sen bzw. Aufrufen

plot(T,X(:,1))	% Darstellung von y_1
plot(T,X(:,2))  % Darstellung von y_2
plot(T,X(:,3))  % Darstellung von y_3
plot(T,X(:,4))  % Darstellung von y_4

function dy = bspDGL2(t,y)
dy = zeros(2,1);
dy(1) = y(2);
dy(2) = 1/1* (1 - 1.*y(1) - 1.*y(2));

function dy = bspDGL(t,y)% 
dy(1) = y(2);
dy(2) = -1/a*y(1);

function dy = bspDGL3(t,y)
dy(1) = y(1);
dy(2) = y(2);
dy(3) = y(3);
dy(4) = 1/a\,(k -  b\, y(1)\,y(3) + y(2))  