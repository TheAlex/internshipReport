% Wichtige Befehle in Matlab

clear all   % L�scht alle Variablen
clear x y   % L�scht Variablen x und y

close all   % Schlie�t alle Fenster

clc         % L�scht Command Window, moralisch wichtig nach Fehlermeldung

doc         % �ffnet Matlab html-basierte Hilfe 
doc plot    % �ffnet Hilfe der plot Funktion
doc filter  % �ffnet Hilfe der filter Funktion

help        % Zeigt gleichen Hilfetext wie doc-Befehl im Command Window an

plot(x,y)    % zeigt Plotfenster mit Diagramm von y �ber x
plot(x,y,'m',x,z,'.k','LineWidth',2,'FontSize',11,'FontName','arial') 
