function zeitverhalten_mks
%
clear       % Workspace l�schen
close all   % offene Bilder schlie�en
global A    % globale Variable zur �bergabe an den DGL-Solver

t0 = 0;             % Startzeitpunkt
tf = 0.200;            % Endzeitpunkt
dt = (tf-t0)/1000;  % Zeitschrit
time = [t0:dt:tf ]; % Zeitachse

% Definition der Systemparameter
%m = 1;  
m1 = 1350;      m2 = 2500;
%c = 1;  
c1 = 200000;    c2 = 500000;
%d = 1;  
d1 = 100;    d2 = 500;
d = (d1+d2);
% d=0;  
c = c1*c2/(c1+c2);


% Matrixdefinition
M = [ m1, 0;
    0,  m2];

C = [ c, -c;
    -c,   c];

D = [ d, -d;
    -d, d];

% Bestimmung der Dimension des Gleichungssystems
n = size(M,1);

% Einheitsmatrix
E = eye(n);

% Nullmatrix
N = zeros(n);

% Matrixtransformation zur Bestimmung der Systemmatrix A
A =[N E;(-1)*inv(M)*C (-1)*inv(M)*D];

% Anfangsbedingungen
x0 = [50/3.6 0 0 0]';   % x = [dx_01 , dx_02 , ddx_01 , ddx_02]

% L�sung der Differentialgleichung
options = [];   % Einstellung der Genauigkeit, siehe auch Dokumentation
[t,x] = ode23(@dgl_mks2,[t0,tf],x0,options);

% Crashdaten einlesen
load('DatCrash.mat')
dat_crash.t = 1/1000*DatCrash.time;
dat_crash.a = DatCrash.ax;
dat_crash.v = 50/3.6+100*DatCrash.v;
dat_crash.s = -0.1*DatCrash.s;

% Plot erzeugen
fig = figure;
subplot(3,2,1)
plot(t,dt*cumsum(x(:,1)),dat_crash.t,dat_crash.s,'m')
ylabel('x [m/s]')
title('Bewegung der Masse m_1')

subplot(3,2,2)
plot(t,dt*cumsum(x(:,2)))
title('Bewegung der Masse m_2')

subplot(3,2,3)
plot(t,x(:,1),dat_crash.t,dat_crash.v,'m')
ylabel('v [m/s]')

subplot(3,2,4)
plot(t,x(:,2))

subplot(3,2,5)
plot(t,x(:,3),dat_crash.t,dat_crash.a,'m')
xlabel('t [s]')
ylabel('a [m/s^2]')

subplot(3,2,6)
plot(t,x(:,4))
xlabel('t [s]')

set(gcf,'Position',[ 9    49   496   636])

function dz = dgl_mks2(t,x)
global A % �bergabe der globalen Variablen

% Definition des substituierten Vektors
dz = zeros(size(A,1),1);

    % Optional: St�rkraft aufbringen
    % Systemanregung f�r Zeitpunkt t1 bis t2
%     k = 0;
%     t1 = 5; t2 = 20;
%     if (t > t1 & t < t2)
%         k = 1*sin(50*t);
%     end
%     
     F = [0; 0; 0; 0];

% DGL-L�sen
dz = A*x + F;

