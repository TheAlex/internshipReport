% 3D Plot am Beispiel der Crashmechanik
clear; close all; clc

ve = 30:1:60;
vo = ve;
v  = 0; 

% 3D-Netz erzeugen
[VE VO] = meshgrid(ve,vo);

% Zielgr��e berechnen
K = abs(v-VE)./abs(VO-v);

% Plot 
mesh(VE./60,VO./60,K);
xlabel('v_{EGO}')
ylabel('v_{Obj}')
set(gcf,'Position',[  30   212   560   349])

% Achsenbegrenzung
zlim([0 2])
ylim([0 1])
xlim([0 1])

% Weitere 3D Plots 
figure;
subplot(2,2,1)
surf(VE./60,VO./60,K); 
xlabel('v_{EGO}'); ylabel('v_{Obj}')

subplot(2,2,2)
surfc(VE./60,VO./60,K); 
xlabel('v_{EGO}'); ylabel('v_{Obj}')

subplot(2,2,[3 4])
meshz(ve./60,vo./60,K); 
xlabel('v_{EGO}'); ylabel('v_{Obj}')

% mit get(gcf,'Position') wird die aktuelle Fenstergr��endefinition gesucht
% welche mit  set(gcf,'Position',[ x1 y1 x2 y2]) gesetzt werden k�nnen
 set(gcf,'Position',[ 606   213   560   349])

    