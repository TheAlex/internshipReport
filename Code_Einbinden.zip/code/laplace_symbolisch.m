% Laplace-R�cktransformation mit Symbolic Tool Box

syms c d m x t s v0
eq = v0*1/(s^2+d/m * s + c/m);

f = ilaplace(eq,s,t)

pretty(f)
